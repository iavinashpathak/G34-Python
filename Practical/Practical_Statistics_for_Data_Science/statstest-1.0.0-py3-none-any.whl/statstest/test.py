import numpy as np

# This will store scores and feedback for all modules, internal use only.
_scores = {}
_feedback = {}

def test_module1(df, student_vars):
    score = 0
    feedback = []

    # Q1
    mean_salary = student_vars.get('mean_salary_by_dept', None)
    if mean_salary is not None and hasattr(mean_salary, 'loc'):
        val = np.round(mean_salary.loc['HR'], -2)
        if val == 52300:
            score += 1
            feedback.append("Q1: Mean salary by department correct.")
        else:
            feedback.append("Q1: Mean salary by department is incorrect.")
    else:
        feedback.append("Q1: Variable or format missing.")

    # Q2
    median_salary = student_vars.get('median_salary_by_dept', None)
    if median_salary is not None and hasattr(median_salary, 'loc'):
        val = median_salary.loc['Engineering']
        if 72000 < val < 80000:
            score += 1
            feedback.append("Q2: Median salary by department correct.")
        else:
            feedback.append("Q2: Median salary by department is incorrect.")
    else:
        feedback.append("Q2: Variable or format missing.")

    # Q3
    department_mode = student_vars.get('department_mode', None)
    if department_mode is not None:
        if isinstance(department_mode, str):
            if department_mode.lower() in ['hr', 'engineering']:
                score += 1
                feedback.append("Q3: Department mode correct.")
            else:
                feedback.append("Q3: Department mode is incorrect.")
        else:
            feedback.append("Q3: Variable format incorrect.")
    else:
        feedback.append("Q3: Variable missing.")

    # Q4
    std_age_hr = student_vars.get('std_age_hr', None)
    if std_age_hr is not None:
        if 2 < std_age_hr < 10:
            score += 1
            feedback.append("Q4: Standard deviation of age in HR correct.")
        else:
            feedback.append("Q4: Standard deviation of age in HR is incorrect.")
    else:
        feedback.append("Q4: Variable missing.")

    _scores['Module 1'] = score
    _feedback['Module 1'] = feedback
    print(f"Module 1 Score: {score}/4")
    for line in feedback:
        print(line)
    print("")
    return score, feedback

def test_module2(df, student_vars):
    score = 0
    feedback = []

    salary_hist_fig = student_vars.get('salary_hist_fig', None)
    age_box_fig = student_vars.get('age_box_fig', None)
    has_outliers = student_vars.get('has_outliers', None)

    # Q1
    if salary_hist_fig is not None and hasattr(salary_hist_fig, 'axes'):
        score += 1
        feedback.append("Q1: Salary histogram figure present.")
    else:
        feedback.append("Q1: Salary histogram figure missing or wrong type.")

    # Q2
    if age_box_fig is not None and hasattr(age_box_fig, 'axes'):
        score += 1
        feedback.append("Q2: Age boxplot figure present.")
    else:
        feedback.append("Q2: Age boxplot figure missing or wrong type.")

    # Q3
    if has_outliers in [True, False]:
        score += 1
        feedback.append("Q3: Outlier detection variable present.")
    else:
        feedback.append("Q3: Outlier detection variable missing or wrong type.")

    _scores['Module 2'] = score
    _feedback['Module 2'] = feedback
    print(f"Module 2 Score: {score}/3")
    for line in feedback:
        print(line)
    print("")
    return score, feedback

def test_module3(df, student_vars):
    score = 0
    feedback = []

    uniform_data = student_vars.get('uniform_data', None)
    uniform_fig = student_vars.get('uniform_fig', None)
    binom_observation = student_vars.get('binom_observation', None)
    clt_reason = student_vars.get('clt_reason', None)

    if uniform_data is not None and isinstance(uniform_data, np.ndarray) and len(uniform_data) == 1000:
        score += 1
        feedback.append("Q1: Uniform distribution simulation correct.")
    else:
        feedback.append("Q1: Uniform distribution variable missing or wrong type.")

    if uniform_fig is not None and hasattr(uniform_fig, 'axes'):
        score += 1
        feedback.append("Q2: Uniform distribution figure present.")
    else:
        feedback.append("Q2: Uniform distribution figure missing or wrong type.")

    if binom_observation is not None and isinstance(binom_observation, str) and len(binom_observation) > 10:
        score += 1
        feedback.append("Q3: Binomial observation answer present.")
    else:
        feedback.append("Q3: Binomial observation variable missing or too short.")

    if clt_reason is not None and isinstance(clt_reason, str) and 'mean' in clt_reason.lower():
        score += 1
        feedback.append("Q4: CLT reason answer present.")
    else:
        feedback.append("Q4: CLT reason variable missing or not mentioning 'mean'.")

    _scores['Module 3'] = score
    _feedback['Module 3'] = feedback
    print(f"Module 3 Score: {score}/4")
    for line in feedback:
        print(line)
    print("")
    return score, feedback

def test_module4(df, student_vars):
    score = 0
    feedback = []

    p_age_mgmt_sales = student_vars.get('p_age_mgmt_sales', None)
    age_diff_significant = student_vars.get('age_diff_significant', None)
    pval_meaning = student_vars.get('pval_meaning', None)
    p_chi2 = student_vars.get('p_chi2', None)

    if p_age_mgmt_sales is not None and isinstance(p_age_mgmt_sales, float) and 0 <= p_age_mgmt_sales <= 1:
        score += 1
        feedback.append("Q1: p-value for age difference present and valid.")
    else:
        feedback.append("Q1: p-value for age difference missing or invalid.")

    if age_diff_significant in [True, False]:
        score += 1
        feedback.append("Q2: Significance variable present.")
    else:
        feedback.append("Q2: Significance variable missing or invalid.")

    if pval_meaning is not None and isinstance(pval_meaning, str) and 'reject' in pval_meaning.lower():
        score += 1
        feedback.append("Q3: p-value meaning answer present and mentions 'reject'.")
    else:
        feedback.append("Q3: p-value meaning variable missing or incomplete.")

    if p_chi2 is not None and isinstance(p_chi2, float) and 0 <= p_chi2 <= 1:
        score += 1
        feedback.append("Q4: Chi-square p-value present and valid.")
    else:
        feedback.append("Q4: Chi-square p-value missing or invalid.")

    _scores['Module 4'] = score
    _feedback['Module 4'] = feedback
    print(f"Module 4 Score: {score}/4")
    for line in feedback:
        print(line)
    print("")
    return score, feedback

def test_module5(df, student_vars):
    score = 0
    feedback = []

    spearman_corr = student_vars.get('spearman_corr', None)
    regression_coefs = student_vars.get('regression_coefs', None)
    neg_corr_meaning = student_vars.get('neg_corr_meaning', None)

    if spearman_corr is not None and isinstance(spearman_corr, float) and -1 <= spearman_corr <= 1:
        score += 1
        feedback.append("Q1: Spearman correlation present and valid.")
    else:
        feedback.append("Q1: Spearman correlation missing or invalid.")

    if regression_coefs is not None and hasattr(regression_coefs, '__iter__') and len(regression_coefs) >= 2:
        score += 1
        feedback.append("Q2: Regression coefficients present and valid.")
    else:
        feedback.append("Q2: Regression coefficients missing or invalid.")

    if neg_corr_meaning is not None and isinstance(neg_corr_meaning, str) and 'decrease' in neg_corr_meaning.lower():
        score += 1
        feedback.append("Q3: Negative correlation meaning answer present and mentions 'decrease'.")
    else:
        feedback.append("Q3: Negative correlation meaning variable missing or incomplete.")

    _scores['Module 5'] = score
    _feedback['Module 5'] = feedback
    print(f"Module 5 Score: {score}/3")
    for line in feedback:
        print(line)
    print("")
    return score, feedback

def get_scores():
    return dict(_scores)

def get_feedback():
    return dict(_feedback)