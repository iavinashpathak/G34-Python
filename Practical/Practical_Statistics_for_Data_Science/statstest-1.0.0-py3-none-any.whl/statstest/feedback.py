from .test import get_scores, get_feedback

def show_final_feedback():
    feedback = get_feedback()
    scores = get_scores()
    total_score = sum(scores.values())
    max_score = 4 + 3 + 4 + 4 + 3  # Modules 1-5 max points
    print("======== DETAILED FEEDBACK ========")
    for module, fb in feedback.items():
        print(f"{module} Feedback:")
        for line in fb:
            print("  ", line)
        print("")
    print(f"FINAL SCORE: {total_score}/{max_score}")
    if total_score == max_score:
        print("Excellent work! All answers are correct.")
    elif total_score > max_score * 0.7:
        print("Good job! Review any modules with less than full marks.")
    else:
        print("You may need to review the material and try again.")